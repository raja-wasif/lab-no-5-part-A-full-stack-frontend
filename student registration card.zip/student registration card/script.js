// ==========================================
// 1. SELECT DOM ELEMENTS (getElementById & querySelector)
// ==========================================

// Form inputs
const registrationForm = document.getElementById('registrationForm');
const fullNameInput = document.getElementById('fullName');
const emailInput = document.querySelector('#email');
const programSelect = document.getElementById('program');
const semesterInput = document.querySelector('#semester');

// Error message placeholders
const fullNameError = document.querySelector('#fullNameError');
const emailError = document.getElementById('emailError');
const programError = document.querySelector('#programError');
const semesterError = document.getElementById('semesterError');

// Preview card elements
const studentCard = document.getElementById('studentCard');
const previewName = document.querySelector('#previewName');
const previewEmail = document.getElementById('previewEmail');
const previewProgram = document.querySelector('#previewProgram');
const previewSemester = document.getElementById('previewSemester');
const cardAvatarText = document.querySelector('#cardAvatarText');

// Mode toggle & student list container
const themeToggleBtn = document.getElementById('themeToggleBtn');
const registeredStudentsList = document.querySelector('#registeredStudentsList');

// Initialize empty list notice
renderEmptyListNotice();


// ==========================================
// 2. LIVE PREVIEW UPDATE (input & change events)
// ==========================================
function updatePreview() {
  const nameValue = fullNameInput.value.trim();
  const emailValue = emailInput.value.trim();
  const programValue = programSelect.value;
  const semesterValue = semesterInput.value;

  // Live update card preview fields
  previewName.textContent = nameValue || 'Jane Doe';
  previewEmail.textContent = emailValue || 'jane.doe@university.edu';
  previewProgram.textContent = programValue || 'Computer Science';
  previewSemester.textContent = semesterValue || '1';

  // Live update avatar initials
  if (nameValue) {
    const parts = nameValue.split(' ').filter(part => part.length > 0);
    if (parts.length >= 2) {
      cardAvatarText.textContent = (parts[0][0] + parts[1][0]).toUpperCase();
    } else {
      cardAvatarText.textContent = parts[0].substring(0, 2).toUpperCase();
    }
  } else {
    cardAvatarText.textContent = 'JD';
  }
}

// Attach input listeners
fullNameInput.addEventListener('input', updatePreview);
emailInput.addEventListener('input', updatePreview);
programSelect.addEventListener('change', updatePreview);
semesterInput.addEventListener('input', updatePreview);


// ==========================================
// 3. DARK / LIGHT MODE TOGGLE (classList.toggle)
// ==========================================
themeToggleBtn.addEventListener('click', function () {
  // Toggle 'dark-mode' class on preview card
  studentCard.classList.toggle('dark-mode');

  // Update button text accordingly
  const isDarkMode = studentCard.classList.contains('dark-mode');
  themeToggleBtn.textContent = isDarkMode ? 'Toggle Card Light Mode ☀️' : 'Toggle Card Dark Mode 🌙';
});


// ==========================================
// 4. FORM VALIDATION & SUBMIT HANDLER
// ==========================================
registrationForm.addEventListener('submit', function (event) {
  // Prevent page reloads on submit
  event.preventDefault();

  // Reset existing error messages via textContent
  fullNameError.textContent = '';
  emailError.textContent = '';
  programError.textContent = '';
  semesterError.textContent = '';

  let isValid = true;

  // Validate Name
  const fullNameVal = fullNameInput.value.trim();
  if (fullNameVal === '') {
    fullNameError.textContent = 'Full Name is required.';
    isValid = false;
  } else if (fullNameVal.length < 2) {
    fullNameError.textContent = 'Full Name must be at least 2 characters.';
    isValid = false;
  }

  // Validate Email
  const emailVal = emailInput.value.trim();
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (emailVal === '') {
    emailError.textContent = 'Email address is required.';
    isValid = false;
  } else if (!emailRegex.test(emailVal)) {
    emailError.textContent = 'Please enter a valid email address.';
    isValid = false;
  }

  // Validate Program Selection
  const programVal = programSelect.value;
  if (programVal === '') {
    programError.textContent = 'Please select a program.';
    isValid = false;
  }

  // Validate Semester Number
  const semesterVal = semesterInput.value.trim();
  const semesterNum = Number(semesterVal);
  if (semesterVal === '') {
    semesterError.textContent = 'Semester is required.';
    isValid = false;
  } else if (isNaN(semesterNum) || semesterNum < 1 || semesterNum > 12) {
    semesterError.textContent = 'Semester must be a number between 1 and 12.';
    isValid = false;
  }

  // ==========================================
  // 5. CREATE & APPEND LIST ITEM IF VALID
  // ==========================================
  if (isValid) {
    // Remove initial empty notice if present
    const emptyNotice = registeredStudentsList.querySelector('.empty-notice');
    if (emptyNotice) {
      emptyNotice.remove();
    }

    // Create new list item (createElement)
    const li = document.createElement('li');
    li.className = 'student-item';

    const infoDiv = document.createElement('div');
    infoDiv.className = 'student-info';

    const nameSpan = document.createElement('span');
    nameSpan.className = 'student-info-name';
    nameSpan.textContent = fullNameVal;

    const metaSpan = document.createElement('span');
    metaSpan.className = 'student-info-meta';
    metaSpan.textContent = `${emailVal} | ${programVal} - Semester ${semesterVal}`;

    infoDiv.appendChild(nameSpan);
    infoDiv.appendChild(metaSpan);

    li.appendChild(infoDiv);

    // Append to Registered Students list
    registeredStudentsList.appendChild(li);

    // Clear form & reset live preview
    registrationForm.reset();
    updatePreview();
  }
});


// Helper function for empty state message
function renderEmptyListNotice() {
  if (registeredStudentsList.children.length === 0) {
    const emptyLi = document.createElement('li');
    emptyLi.className = 'empty-notice';
    emptyLi.textContent = 'No registered students yet. Fill out the form above to add one.';
    registeredStudentsList.appendChild(emptyLi);
  }
}